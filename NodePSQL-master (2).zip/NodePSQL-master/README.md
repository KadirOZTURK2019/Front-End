# NodePSQL

<h1>Postgre SQL Nodejs </h1>
<p> Postgre SQL üzerinden API operasyonları </p>
