const Pool = require('pg').Pool
const basemanager = require('./basemanager')
const db = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'ChatManDB',
    password: '123',
    port: 5432,
  });

var tablename = "adminuser";

function getallusers (take,response)  {
    db.query(basemanager.getall(tablename), (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).json(results.rows)
    })
  }


  module.exports = {
    getallusers : getallusers
  }