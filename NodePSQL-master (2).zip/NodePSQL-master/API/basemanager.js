

function getall(tablename){
    return "SELECT * FROM "+ tablename +" where isdelete = false";
}

function getallbytake(tablename,take){
  return "SELECT *" +" FROM "+tablename +" where isdelete = false limit "+ take;
}

module.exports = {
    getall,
    getallbytake
}